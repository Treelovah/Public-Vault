#ifndef GET_INPUT_H_INCLUDED
#define GET_INPUT_H_INCLUDED

int get_input();

#endif