#include "split_string.h"
#include "get_input.h"
#include <iostream>
int main() {
    std::cout << get_input();
    return 0;
}
