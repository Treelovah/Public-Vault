#ifndef SPLIT_STRING_H_INCLUDED
#define SPLIT_STRING_H_INCLUDED
#include <string>
int split_string(std::string data);
int proper_date(std::string str_year, std::string str_day);
#endif